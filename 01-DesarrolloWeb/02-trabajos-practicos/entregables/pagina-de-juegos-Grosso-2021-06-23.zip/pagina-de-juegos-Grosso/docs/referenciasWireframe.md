# Referencias del wireframe


1. Carrousel con imagenes del juego
2. Imagen con descripcion a un costado (cuando se vea flexbox voy a hacerlo)
3. Imagen en parallax
4. Videos del juego

  **Hecho por Nicolás Grosso para *CoderHouse***